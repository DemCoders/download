#!/bin/bash

/usr/local/bin/kubectl port-forward --address 0.0.0.0 svc/a360-memcached 11211:11211 -n default &
/usr/local/bin/kubectl port-forward --address 0.0.0.0 svc/arbiter 30000:80 -n default &
/usr/local/bin/kubectl port-forward --address 0.0.0.0 svc/narro 30001:80 -n default &
/usr/local/bin/kubectl port-forward --address 0.0.0.0 svc/noto 30589:80 -n default &

