#!/bin/bash
az aks get-credentials --name ${1} -g ${2} --subscription 32042f9e-eb10-401e-a87e-104cca2c379a
kubectl create clusterrolebinding serviceaccounts-cluster-admin  --clusterrole=cluster-admin --group=system:serviceaccounts
kubectl create configmap bgb-config --from-env-file ./configmap/bgb-config.yml -o yaml --dry-run=client | kubectl apply -f - && kubectl create configmap ms-graph-config --from-env-file ./configmap/ms-graph-config.yml -o yaml --dry-run=client | kubectl apply -f -
helm repo add ingress-nginx https://kubernetes.github.io/ingress-nginx
helm install ingress-nginx/ingress-nginx --version 4.0.19 --set controller.extraArgs.v=3 --set controller.replicaCount=2 --set rbac.create=true --set controller.service.appProtocol=false --generate-name -f ./network/load_balancer.yml
echo "[INFO] Sleeping for 30 seconds"
sleep 30
echo "[INFO] Trying to run ingress.yml"
kubectl apply -f ./network/ingress.yml
kubectl apply -f ./core/acr.yml -f ./core/services.yml -f ./core -f ./dotnet -f ./slack
