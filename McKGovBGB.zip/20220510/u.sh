#!/bin/bash

# uE4mD5lX6bR7bO8mF4fD4lV0xJ2nW3qQ

H=$(hostname)

echo "${H}: running on $(hostname) as $(whoami) in $(pwd) PubIP: $(curl -s ifconfig.io)"

# echo cp -f a2z.{crt,key} /etc/ssl/certs/
# echo cp -f a2z.pw /root/password.pw
# echo sed -i 's/ssl_key_passphrase.*/ssl_key_passphrase => "uE4mD5lX6bR7bO8mF4fD4lV0xJ2nW3qQ"/g' /etc/logstash/conf.d/logstash.conf

# echo "DEBUG only"
# exit 0

echo -n "${H}: local copy: "
cp -f a2z.* /etc/ssl/certs/
cp -f a2z.pw /root/password.pw
ls -l /etc/ssl/certs/a2z.* /root/password.pw
echo "DONE"

echo -n "${H}: logstash config update: "
sed -i 's/ssl_key_passphrase.*/ssl_key_passphrase => "uE4mD5lX6bR7bO8mF4fD4lV0xJ2nW3qQ"/g' /etc/logstash/conf.d/logstash.conf
echo "DONE"

echo "==== NEW CRT [ ${H} ]============================================="
openssl x509 -in /etc/ssl/certs/a2z.crt -noout -dates -subject
echo "=================================================================="

echo "${H}: reloading nginx"
systemctl restart nginx
# /usr/sbin/nginx -s reload

echo "${H}: restarting logstash"
systemctl restart logstash

echo "${H}: done"